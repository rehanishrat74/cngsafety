
--
-- Indexes for dumped tables
--

--
-- Indexes for table `AccessRights`
--
ALTER TABLE `AccessRights`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`Rank`);

--
-- Indexes for table `cng_kit`
--
ALTER TABLE `cng_kit`
  ADD PRIMARY KEY (`formid`,`CngKitSerialNo`,`InspectionDate`);

--
-- Indexes for table `CodeRollsPrimary`
--
ALTER TABLE `CodeRollsPrimary`
  ADD PRIMARY KEY (`batchid`);

--
-- Indexes for table `CodeRollsSecondary`
--
ALTER TABLE `CodeRollsSecondary`
  ADD UNIQUE KEY `serialno` (`serialno`);

--
-- Indexes for table `cylinderbrand`
--
ALTER TABLE `cylinderbrand`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cylinder_locations`
--
ALTER TABLE `cylinder_locations`
  ADD PRIMARY KEY (`Location_id`),
  ADD UNIQUE KEY `cylinder_locations_location_name_unique` (`Location_name`);

--
-- Indexes for table `kit_cylinders`
--
ALTER TABLE `kit_cylinders`
  ADD PRIMARY KEY (`formid`,`Make_Model`,`Cylinder_SerialNo`,`InspectionDate`,`CngKitSerialNo`);

--
-- Indexes for table `logcngkit`
--
ALTER TABLE `logcngkit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logcylinders`
--
ALTER TABLE `logcylinders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logdoGeneratePin`
--
ALTER TABLE `logdoGeneratePin`
  ADD PRIMARY KEY (`logid`);

--
-- Indexes for table `logdoverifycode`
--
ALTER TABLE `logdoverifycode`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logparticulars`
--
ALTER TABLE `logparticulars`
  ADD PRIMARY KEY (`logid`);

--
-- Indexes for table `owner__particulars`
--
ALTER TABLE `owner__particulars`
  ADD PRIMARY KEY (`CNIC`,`VehicleReg_No`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `RegisteredCylinders`
--
ALTER TABLE `RegisteredCylinders`
  ADD PRIMARY KEY (`id`,`BrandName`,`SerialNumber`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `vehicle_categories`
--
ALTER TABLE `vehicle_categories`
  ADD PRIMARY KEY (`category_id`),
  ADD UNIQUE KEY `vehicle_category_category_name_unique` (`category_name`);

--
-- Indexes for table `vehicle_particulars`
--
ALTER TABLE `vehicle_particulars`
  ADD PRIMARY KEY (`Registration_no`,`OwnerCnic`),
  ADD UNIQUE KEY `Record_no_UNIQUE` (`Record_no`);

--
-- Indexes for table `worldcountries`
--
ALTER TABLE `worldcountries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `x1CodeRollsPrimary`
--
ALTER TABLE `x1CodeRollsPrimary`
  ADD PRIMARY KEY (`batchid`);

--
-- Indexes for table `x1CodeRollsSecondary`
--
ALTER TABLE `x1CodeRollsSecondary`
  ADD UNIQUE KEY `serialno` (`serialno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `AccessRights`
--
ALTER TABLE `AccessRights`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `cng_kit`
--
ALTER TABLE `cng_kit`
  MODIFY `formid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=199;

--
-- AUTO_INCREMENT for table `CodeRollsPrimary`
--
ALTER TABLE `CodeRollsPrimary`
  MODIFY `batchid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- AUTO_INCREMENT for table `cylinderbrand`
--
ALTER TABLE `cylinderbrand`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `cylinder_locations`
--
ALTER TABLE `cylinder_locations`
  MODIFY `Location_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `logcngkit`
--
ALTER TABLE `logcngkit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `logcylinders`
--
ALTER TABLE `logcylinders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `logdoGeneratePin`
--
ALTER TABLE `logdoGeneratePin`
  MODIFY `logid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `logdoverifycode`
--
ALTER TABLE `logdoverifycode`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `logparticulars`
--
ALTER TABLE `logparticulars`
  MODIFY `logid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `RegisteredCylinders`
--
ALTER TABLE `RegisteredCylinders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12384;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;

--
-- AUTO_INCREMENT for table `vehicle_categories`
--
ALTER TABLE `vehicle_categories`
  MODIFY `category_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `vehicle_particulars`
--
ALTER TABLE `vehicle_particulars`
  MODIFY `Record_no` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=232;

--
-- AUTO_INCREMENT for table `worldcountries`
--
ALTER TABLE `worldcountries`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=204;

--
-- AUTO_INCREMENT for table `x1CodeRollsPrimary`
--
ALTER TABLE `x1CodeRollsPrimary`
  MODIFY `batchid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `kit_cylinders`
--
ALTER TABLE `kit_cylinders`
  ADD CONSTRAINT `kit_cylinders_ibfk_1` FOREIGN KEY (`formid`) REFERENCES `cng_kit` (`formid`);
