
-- --------------------------------------------------------

--
-- Table structure for table `worldcountries`
--

CREATE TABLE `worldcountries` (
  `id` int(3) NOT NULL,
  `countries` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `worldcountries`
--

INSERT INTO `worldcountries` (`id`, `countries`) VALUES
(196, 'Italy'),
(197, 'Austria'),
(198, 'India'),
(199, 'China'),
(200, 'Brazil'),
(201, 'Dubai'),
(202, 'Argentina'),
(203, 'Armenia');
