
-- --------------------------------------------------------

--
-- Table structure for table `logdoverifycode`
--

CREATE TABLE `logdoverifycode` (
  `stationno` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `logdoverifycode`
--

INSERT INTO `logdoverifycode` (`stationno`, `code`, `id`) VALUES
('PID-15', 'AFSRUUDK5', 1),
('PFJ-1', '060AZ4U7N', 2),
('PID-13', '060AZ4U7N', 3),
('PID-17', 'ALCXXTAE5', 4),
('PID-17', 'ALCXXTAE5', 5),
('PID-17', 'PB6TJ8QMY', 6),
('PID-17', 'PB6TJ8QMY', 7),
('PID-17', 'WQE9NG5B1', 8),
('PID-17', 'O8MAPN6JH', 9),
('PID-17', 'O8MAPN6JH', 10),
('PID-17', 'EYONEIEGX', 11),
('PID-17', 'EYONEIEGX', 12),
('PID-13', '060AZ4U7N', 13),
('PID-13', '060AZ4U7N', 14),
('PID-13', '060AZ4U7N', 15),
('PID-13', '060AZ4U7N', 16),
('PID-17', '3KJ1TYTYH', 17),
('PID-17', 'IXQ8EG4H0', 18),
('PID-17', 'XQLTYNOG0', 19),
('PID-17', 'I0ONQIFHE', 20),
('PID-17', 'XQLTYNOG0', 21),
('PID-13', '060AZ4U7N', 22),
('PID-13', '060AZ4U7N', 23);
