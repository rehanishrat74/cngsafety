
-- --------------------------------------------------------

--
-- Table structure for table `logcngkit`
--

CREATE TABLE `logcngkit` (
  `id` int(11) NOT NULL,
  `userid` varchar(191) COLLATE utf8mb4_bin DEFAULT NULL,
  `code` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `workstationid` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `cylinderno` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `expiryDate` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `registration_no` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `vehicleRecordNo` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `scan_code` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `o_cnic` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `ck_make_n_model` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `ck_serial_no` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `ck_is_cylinder_valve` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `ck_is_filling_valve` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `ck_is_reducer` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `ck_is_high_pressure_pipe` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `ck_is_exhaust_pipe` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `isproduction` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `created_at` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `logcngkit`
--

INSERT INTO `logcngkit` (`id`, `userid`, `code`, `workstationid`, `cylinderno`, `expiryDate`, `registration_no`, `vehicleRecordNo`, `scan_code`, `o_cnic`, `ck_make_n_model`, `ck_serial_no`, `ck_is_cylinder_valve`, `ck_is_filling_valve`, `ck_is_reducer`, `ck_is_high_pressure_pipe`, `ck_is_exhaust_pipe`, `isproduction`, `created_at`) VALUES
(1, '79', 'O8MAPN6JH', 'PID-17', '3', '2020-12-31', 'dfh-853', '0', 'O8MAPN6JH', '62238-6438521-3', 'landiranzo', '456', 'on', 'on', 'off', 'off', 'off', '1', '2020-03-13'),
(2, '79', 'EYONEIEGX', 'PID-17', '3', '2020-12-31', 'ff-666', '0', 'EYONEIEGX', '62295-5234856-6', 'yy', 'landiranzo', 'on', 'on', 'off', 'off', 'off', '1', '2020-03-13'),
(3, '52', '060AZ4U7N', 'PID-13', '3', '2020-12-31', 'KZ66 ZYT', '0', '060AZ4U7N', '37201145841152', 'TOYOTA HIACE', '134xy65', 'off', 'on', 'off', 'on', 'off', '1', '2020-03-17'),
(4, '52', '060AZ4U7N', 'PID-13', '3', '2020-12-31', 'KZ66 ZYT', '0', '060AZ4U7N', '37201145841152', 'TOYOTA HIACE', '134xy65', 'on', 'off', 'on', 'on', 'off', '1', '2020-03-17'),
(5, '79', '3KJ1TYTYH', 'PID-17', '3', '2020-12-31', 'rr-652', '0', '3KJ1TYTYH', '45502-6985215-6', 'lanfiranzo', '456', 'on', 'off', 'off', 'off', 'off', '1', '2020-03-17'),
(6, '79', '3KJ1TYTYH', 'PID-17', '3', '2020-12-31', 'rr-652', '0', '3KJ1TYTYH', '45502-6985215-6', 'landiranzo', '124', 'on', 'off', 'off', 'off', 'off', '1', '2020-03-17'),
(7, '79', 'IXQ8EG4H0', 'PID-17', '4', '2020-12-31', 'tt-654', '0', 'IXQ8EG4H0', '78806-9852147-6', 'landiranzo', '466', 'on', 'off', 'off', 'off', 'off', '1', '2020-03-17'),
(8, '79', 'XQLTYNOG0', 'PID-17', '1', '2020-12-31', 'tt-66', '0', 'XQLTYNOG0', '43201-6985214-3', 'landiranzo', '55', 'on', 'off', 'off', 'off', 'off', '1', '2020-03-17'),
(9, '79', 'I0ONQIFHE', 'PID-17', '1', '2020-12-31', 'y-653', '0', 'I0ONQIFHE', '42212-6523145-3', 'l', '5', 'on', 'off', 'off', 'off', 'off', '1', '2020-03-17'),
(10, '79', 'XQLTYNOG0', 'PID-17', '1', '2020-12-31', 'tt-66', '0', 'XQLTYNOG0', '43201-6985214-3', 'landiranzo', '457', 'on', 'off', 'off', 'off', 'off', '1', '2020-03-18'),
(11, '52', '060AZ4U7N', 'PID-13', '2', '2020-12-31', NULL, '0', '060AZ4U7N', '37201145841152', 'TOYOTA HIACE', '134xy65', 'off', 'on', 'on', 'on', 'off', '1', '2020-03-19'),
(12, '52', '060AZ4U7N', 'PID-13', '2', '2020-12-31', NULL, '0', '060AZ4U7N', '37201145841152', 'TOYOTA HIACE', '134xy65', 'off', 'on', 'on', 'on', 'off', '1', '2020-03-19'),
(13, '52', '060AZ4U7N', 'PID-13', '2', '2020-12-31', NULL, '0', '060AZ4U7N', '37201145841152', 'TOYOTA HIACE', '134xy65', 'on', 'off', 'on', 'on', 'off', '1', '2020-03-19');
