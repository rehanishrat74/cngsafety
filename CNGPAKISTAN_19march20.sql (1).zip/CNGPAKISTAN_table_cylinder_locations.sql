
-- --------------------------------------------------------

--
-- Table structure for table `cylinder_locations`
--

CREATE TABLE `cylinder_locations` (
  `Location_id` int(10) UNSIGNED NOT NULL,
  `Location_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cylinder_locations`
--

INSERT INTO `cylinder_locations` (`Location_id`, `Location_name`, `created_at`, `updated_at`) VALUES
(1, 'Trunk', NULL, NULL),
(2, 'Rear of vehicle', NULL, NULL),
(3, 'Roof top ', NULL, NULL),
(4, 'Under carriage ', NULL, NULL);
