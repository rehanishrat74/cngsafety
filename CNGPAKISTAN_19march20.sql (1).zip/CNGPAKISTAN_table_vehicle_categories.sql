
-- --------------------------------------------------------

--
-- Table structure for table `vehicle_categories`
--

CREATE TABLE `vehicle_categories` (
  `category_id` int(10) UNSIGNED NOT NULL,
  `category_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `vehicle_categories`
--

INSERT INTO `vehicle_categories` (`category_id`, `category_name`, `created_at`, `updated_at`) VALUES
(1, 'PSV', NULL, NULL),
(2, 'Private', NULL, NULL),
(3, 'Ambulance', NULL, NULL),
(4, 'Cargo', NULL, NULL),
(5, 'School van', NULL, NULL),
(6, 'Other', NULL, NULL);
