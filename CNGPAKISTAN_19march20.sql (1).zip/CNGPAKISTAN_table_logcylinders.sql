
-- --------------------------------------------------------

--
-- Table structure for table `logcylinders`
--

CREATE TABLE `logcylinders` (
  `id` int(11) NOT NULL,
  `userid` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `code` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `scan_code` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `o_cnic` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `totalcylinders` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `lastinspectionid` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `workstationid` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `registration_no` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `oinspectiondate` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `kitserialno` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `location_1` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `standard_1` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `makenmodel_1` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `serialno_1` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `oimportdate_1` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `location_2` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `standard_2` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `makenmodel_2` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `serialno_2` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `oimportdate_2` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `location_3` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `standard_3` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `makenmodel_3` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `serialno_3` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `oimportdate_3` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `location_4` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `standard_4` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `makenmodel_4` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `serialno_4` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `oimportdate_4` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `location_5` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `standard_5` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `makenmodel_5` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `serialno_5` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `oimportdate_5` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `location_6` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `standard_6` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `makenmodel_6` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `serialno_6` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `oimportdate_6` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `isproduction` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `created_at` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `logcylinders`
--

INSERT INTO `logcylinders` (`id`, `userid`, `code`, `scan_code`, `o_cnic`, `totalcylinders`, `lastinspectionid`, `workstationid`, `registration_no`, `oinspectiondate`, `kitserialno`, `location_1`, `standard_1`, `makenmodel_1`, `serialno_1`, `oimportdate_1`, `location_2`, `standard_2`, `makenmodel_2`, `serialno_2`, `oimportdate_2`, `location_3`, `standard_3`, `makenmodel_3`, `serialno_3`, `oimportdate_3`, `location_4`, `standard_4`, `makenmodel_4`, `serialno_4`, `oimportdate_4`, `location_5`, `standard_5`, `makenmodel_5`, `serialno_5`, `oimportdate_5`, `location_6`, `standard_6`, `makenmodel_6`, `serialno_6`, `oimportdate_6`, `isproduction`, `created_at`) VALUES
(1, '79', 'O8MAPN6JH', 'O8MAPN6JH', '62238-6438521-3', '3', '0', 'PID-17', 'dfh-853', '2020-03-13 00:00:00.000', '456', '2', 'NZS 5454-1989', '', '', '2020-03-12 00:00:00.000', '', 'NZS 5454-1989', '', '765', '2020-03-20 00:00:00.000', '3', 'NZS 5454-1989', 'hgf', '634', NULL, '', '', '', '', NULL, '', '', '', '', NULL, '', '', '', '', NULL, '1', '2020-03-13 00:00:00'),
(2, '79', 'O8MAPN6JH', 'O8MAPN6JH', '62238-6438521-3', '3', '0', 'PID-17', 'dfh-853', '2020-03-13 00:00:00.000', '456', '2', 'NZS 5454-1989', '', '', '2020-03-12 00:00:00.000', '', 'NZS 5454-1989', '', '765', '2020-03-20 00:00:00.000', '3', 'NZS 5454-1989', 'hgf', '634', '2020-03-20 00:00:00.000', '', '', '', '', NULL, '', '', '', '', NULL, '', '', '', '', NULL, '1', '2020-03-13 00:00:00'),
(3, '79', 'EYONEIEGX', 'EYONEIEGX', '62295-5234856-6', '3', '0', 'PID-17', 'ff-666', '2020-03-20 00:00:00.000', 'landiranzo', '2', 'NZS 5454-1989', '', '', '2020-03-26 00:00:00.000', '3', 'NZS 5454-1989', '', '777', '2020-03-04 00:00:00.000', '4', 'NZS 5454-1989', 'ekc', '777', '2020-03-25 00:00:00.000', '', '', '', '', NULL, '', '', '', '', NULL, '', '', '', '', NULL, '1', '2020-03-13 00:00:00'),
(4, '79', 'EYONEIEGX', 'EYONEIEGX', '62295-5234856-6', '3', '0', 'PID-17', 'ff-666', '2020-03-20 00:00:00.000', 'landiranzo', '2', 'NZS 5454-1989', '', '', '2020-03-26 00:00:00.000', '3', 'NZS 5454-1989', '', '777', '2020-03-04 00:00:00.000', '4', 'NZS 5454-1989', 'ekc', '777', '2020-03-25 00:00:00.000', '', '', '', '', NULL, '', '', '', '', NULL, '', '', '', '', NULL, '1', '2020-03-13 00:00:00'),
(5, '52', '060AZ4U7N', '060AZ4U7N', '37201145841152', '3', '0', 'PID-13', 'KZ66 ZYT', '2020-03-25 00:00:00.000', '134xy65', '2', 'ISO 11439', '', '', '2020-03-27 00:00:00.000', '3', 'ISO 11439', 'BTC', 'Test15481', '2020-03-13 00:00:00.000', '4', 'NZS 5454-1989', 'BTC', 'Test15482', '2020-03-30 00:00:00.000', '', '', '', '', NULL, '', '', '', '', NULL, '', '', '', '', NULL, '1', '2020-03-17 00:00:00'),
(6, '52', '060AZ4U7N', '060AZ4U7N', '37201145841152', '3', '0', 'PID-13', 'KZ66 ZYT', '2020-03-25 00:00:00.000', '134xy65', '2', 'ISO 11439', '', '', '2020-03-27 00:00:00.000', '3', 'ISO 11439', 'BTC', 'Test15481', '2020-03-13 00:00:00.000', '4', 'NZS 5454-1989', 'BTC', 'Test15482', '2020-03-30 00:00:00.000', '', '', '', '', NULL, '', '', '', '', NULL, '', '', '', '', NULL, '1', '2020-03-17 00:00:00'),
(7, '52', '060AZ4U7N', '060AZ4U7N', '37201145841152', '3', '0', 'PID-13', 'KZ66 ZYT', '2020-03-25 00:00:00.000', '134xy65', '3', 'ISO 11439', '', '', '2020-03-27 00:00:00.000', '2', 'ISO 11439', 'BTC', 'Test15481', '2020-03-26 00:00:00.000', '2', 'ISO 11439', 'BTC', 'Test15482', '2020-03-27 00:00:00.000', '', '', '', '', NULL, '', '', '', '', NULL, '', '', '', '', NULL, '1', '2020-03-17 00:00:00'),
(8, '52', '060AZ4U7N', '060AZ4U7N', '37201145841152', '3', '0', 'PID-13', 'KZ66 ZYT', '2020-03-26 00:00:00.000', '134xy65', '3', 'ISO 11439', '', '', '2020-03-28 00:00:00.000', '2', 'NZS 5454-1989', 'BTC2', 'Test15481', '2020-03-31 00:00:00.000', '2', 'ISO 11439', 'BTC3', 'Test15482', '2020-03-29 00:00:00.000', '', '', '', '', NULL, '', '', '', '', NULL, '', '', '', '', NULL, '1', '2020-03-17 00:00:00'),
(9, '52', '060AZ4U7N', '060AZ4U7N', '37201145841152', '3', '0', 'PID-13', 'KZ66 ZYT', '2020-03-26 00:00:00.000', '134xy65', '3', 'ISO 11439', '', '', '2020-03-28 00:00:00.000', '2', 'NZS 5454-1989', 'BTC2', 'Test15481', '2020-03-31 00:00:00.000', '2', 'ISO 11439', 'BTC3', 'Test15482', '2020-03-29 00:00:00.000', '', '', '', '', NULL, '', '', '', '', NULL, '', '', '', '', NULL, '1', '2020-03-17 00:00:00'),
(10, '52', '060AZ4U7N', '060AZ4U7N', '37201145841152', '3', '0', 'PID-13', 'KZ66 ZYT', '2020-03-26 00:00:00.000', '134xy65', '3', 'ISO 11439', 'BTC3', 'Test15485', '2020-03-28 00:00:00.000', '2', 'NZS 5454-1989', 'BTC27', 'Test154815', '2020-03-31 00:00:00.000', '2', 'ISO 11439', 'BTC33', 'Test154827', '2020-03-29 00:00:00.000', '', '', '', '', NULL, '', '', '', '', NULL, '', '', '', '', NULL, '1', '2020-03-17 00:00:00'),
(11, '79', '3KJ1TYTYH', '3KJ1TYTYH', '45502-6985215-6', '3', '0', 'PID-17', 'rr-652', '2020-03-01 00:00:00.000', '124', '1', 'NZS 5454-1989', 'ekc', '123', '2020-03-01 00:00:00.000', '2', '', 'ekc', '456', '2020-03-02 00:00:00.000', '3', 'NZS 5454-1989', 'ekc', '788', '2020-03-07 00:00:00.000', '', '', '', '', NULL, '', '', '', '', NULL, '', '', '', '', NULL, '1', '2020-03-17 00:00:00'),
(12, '79', 'IXQ8EG4H0', 'IXQ8EG4H0', '78806-9852147-6', '4', '0', 'PID-17', 'tt-654', '2020-03-17 00:00:00.000', '466', '1', 'NZS 5454-1989', '*cidgas', 'Tedt1313', '2020-03-02 00:00:00.000', '2', 'NZS 5454-1989', '*cidgas', 'TEST201302b', '2020-03-02 00:00:00.000', '2', 'NZS 5454-1989', '*cidgas', 'TEST201202', '2020-03-03 00:00:00.000', '4', 'NZS 5454-1989', '*cidgas', 'Test1212', '2020-03-04 00:00:00.000', '', '', '', '', NULL, '', '', '', '', NULL, '1', '2020-03-17 00:00:00'),
(13, '79', 'XQLTYNOG0', 'XQLTYNOG0', '43201-6985214-3', '1', '0', 'PID-17', 'tt-66', '2020-03-01 00:00:00.000', '55', '3', 'NZS 5454-1989', '*cidgas', 'Test1313', '2020-03-01 00:00:00.000', '', '', '', '', NULL, '', '', '', '', NULL, '', '', '', '', NULL, '', '', '', '', NULL, '', '', '', '', NULL, '1', '2020-03-17 00:00:00'),
(14, '79', 'I0ONQIFHE', 'I0ONQIFHE', '42212-6523145-3', '1', '0', 'PID-17', 'y-653', '2020-03-01 00:00:00.000', '5', '2', 'NZS 5454-1989', '*Cidgas', 'Test1212', '2020-03-01 00:00:00.000', '', '', '', '', NULL, '', '', '', '', NULL, '', '', '', '', NULL, '', '', '', '', NULL, '', '', '', '', NULL, '1', '2020-03-17 00:00:00'),
(15, '79', 'XQLTYNOG0', 'XQLTYNOG0', '43201-6985214-3', '1', '0', 'PID-17', 'tt-66', '2020-03-01 00:00:00.000', '457', '2', 'NZS 5454-1989', 'EKC', 'Test1212', '2020-03-01 00:00:00.000', '', '', '', '', NULL, '', '', '', '', NULL, '', '', '', '', NULL, '', '', '', '', NULL, '', '', '', '', NULL, '1', '2020-03-18 00:00:00');
