
-- --------------------------------------------------------

--
-- Table structure for table `cylinderbrand`
--

CREATE TABLE `cylinderbrand` (
  `id` int(2) NOT NULL,
  `brandname` varchar(191) DEFAULT NULL,
  `designatedInspector` varchar(191) DEFAULT NULL,
  `remarks` varchar(191) DEFAULT NULL,
  `Standard` varchar(191) DEFAULT NULL,
  `diameter` varchar(45) DEFAULT NULL,
  `length` varchar(45) DEFAULT NULL,
  `wlc` varchar(45) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cylinderbrand`
--

INSERT INTO `cylinderbrand` (`id`, `brandname`, `designatedInspector`, `remarks`, `Standard`, `diameter`, `length`, `wlc`) VALUES
(23, 'Kioshi Compresion', 'Lloyd\'s, Bureau Veritas, ABS, SGS', '', 'NZS 5454-1989', '280mm', NULL, '40-90 WLC'),
(24, 'Kioshi Compresion', 'Lloyd\'s, Bureau Veritas, ABS, SGS', '', 'NZS 5454-1989', '340mm', NULL, '50-74 WLC'),
(25, 'Kioshi Compresion', 'Lloyd\'s, Bureau Veritas, ABS, SGS', '', 'NZS 5454-1989', '323mm', NULL, '41-64 WLC'),
(26, 'Kioshi Compresion', 'Lloyd\'s, Bureau Veritas, ABS, SGS', '', 'NZS 5454-1989', '273mm', NULL, '30-90 WLC'),
(27, 'Faber Industries', 'Lloyd\'s, Bureau Veritas, ABS, SGS', '', 'NZS 5454-1989', NULL, NULL, NULL),
(28, 'Dalmine spa', 'Lloyd\'s, Bureau Veritas, ABS, SGS', '', 'NZS 5454-1989', NULL, NULL, NULL),
(29, 'Washington Cyiinder', 'Lloyd\'s, Bureau Veritas, ABS, SGS', '', 'NZS 5454-1989', NULL, NULL, NULL),
(30, 'Everest Kanto Cylinder Ltd	', 'Lloyd\'s, Bureau Veritas, ABS, SGS', '', 'NZS 5454-1989', NULL, NULL, NULL),
(31, 'Inflex', 'Lloyd\'s, Bureau Veritas, ABS, SGS', '', 'NZS 5454-1989', NULL, NULL, NULL),
(32, 'Beijing Tianhai Industrial Co (BTIC)', 'Lloyd\'s, Bureau Veritas, ABS, SGS', '', 'NZS 5454-1989', NULL, NULL, NULL),
(33, 'Cilbras', 'Lloyd\'s, Bureau Veritas, ABS, SGS', '', 'NZS 5454-1989', NULL, NULL, NULL),
(34, 'EKC', 'Lloyd\'s, Bureau Veritas, ABS, SGS', '', 'NZS 5454-1989', NULL, NULL, NULL),
(35, '*Rama Cylinders (Pvt) Ltd', 'Lloyd\'s, Bureau Veritas, ABS, SGS', '', 'NZS 5454-1989', NULL, NULL, NULL),
(36, '*Nitin Cylinders (Pvt) Ltd', '-SGS- All Tests carried out by International Lab Powertech Inc Canada', '', 'NZS 5454-1989', '325 mm', NULL, '50-140 WLC'),
(37, '*Nitin Cylinders (Pvt) Ltd', '-SGS- All Tests carried out by International Lab Powertech Inc Canada', '', 'NZS 5454-1989', '267 mm', NULL, '30-85 WLC'),
(38, '*Cidegas', 'Bureau Veritas', '', 'NZS 5454-1989', '316mm', '912mm', '58 WLC'),
(39, '*Lizer Cylinders Limited', '-SGS-', '', 'NZS 5454-1989', '317mm', '830mm', '50 WLC'),
(40, '*Lizer Cylinders Limited', '-SGS-', '', 'NZS 5454-1989', '267mm', '1725mm', '80 WLC'),
(41, '*Lizer Cylinders Limited', '-SGS-', '', 'NZS 5454-1989', '317mm', '900mm', '55 WLC'),
(42, '*Lizer Cylinders Limited', '-SGS-', '', 'NZS 5454-1989', '267mm', '730mm', '30 WLC'),
(43, '*Maruti Koatsu Cylinder (Pvt) Ltd', 'Lloyd\'s, Bureau Veritas, ABS, SGS', '', 'NZS 5454-1989', NULL, NULL, NULL),
(44, 'Inprocil  S.A', 'Lloyd\'s, Bureau Veritas, ABS, SGS', '', 'NZS 5454-1989', NULL, NULL, NULL),
(45, '*M/s. International Gas Vessels Industries (IGVI)', 'Bureau Veritas', '', 'NZS 5454-1989', NULL, NULL, NULL),
(46, 'M/s. Mat S/A', 'Lloyd\'s, Bureau Veritas, ABS, SGS', '', 'NZS 5454-1989', NULL, '920mm', '62 WLC'),
(47, 'Associate High Pressure Technologies Pvt Lts (India)', 'Lloyd\'s, Bureau Veritas, ABS, SGS', NULL, 'NZS 5454-1989', NULL, NULL, '20 WLC'),
(48, 'Associate High Pressure Technologies Pvt Lts (India)', 'Lloyd\'s, Bureau Veritas, ABS, SGS', NULL, 'NZS 5454-1989', NULL, NULL, '30'),
(49, 'Associate High Pressure Technologies Pvt Lts (India)', 'Lloyd\'s, Bureau Veritas, ABS, SGS', NULL, 'NZS 5454-1989', NULL, NULL, '30'),
(50, 'Associate High Pressure Technologies Pvt Lts (India)', 'Lloyd\'s, Bureau Veritas, ABS, SGS', NULL, 'NZS 5454-1989', NULL, NULL, '30 WLC');
