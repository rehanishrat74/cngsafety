
-- --------------------------------------------------------

--
-- Table structure for table `AccessRights`
--

CREATE TABLE `AccessRights` (
  `id` int(11) NOT NULL,
  `regtype` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `functionname` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `routename` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `iconClass` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `AccessRights`
--

INSERT INTO `AccessRights` (`id`, `regtype`, `functionname`, `routename`, `iconClass`) VALUES
(1, 'admin', 'Registered Users', 'view-records', 'fa-users'),
(2, 'admin', 'Inspected Vehicles', 'registrations', 'fa-car'),
(3, 'admin', 'New Vehicle', 'newvehicle', 'fa-car'),
(4, 'admin', 'Cylinder Inspection', 'labtestedcylinders', 'fa-bolt'),
(24, 'admin', 'Workshops', 'Workshops', 'fa-users'),
(22, 'workshop', 'New Vehicle', 'newvehicle', 'fa-car'),
(21, 'workshop', 'Inspected Vehicles', 'registrations', 'fa-car'),
(9, 'laboratory', 'Cylinder Inspection', 'labtestedcylinders', 'fa-bolt'),
(10, 'hdip', 'Labs', 'showlabs', 'fa-sitemap'),
(12, 'hdip', 'Tested Cylinders', 'listlabtestedcylinders', 'fa-thumbs-o-up'),
(14, 'laboratory', 'Tested Cylinders', 'listlabtestedcylinders', 'fa-thumbs-o-up'),
(15, 'admin', 'Tested Cylinders', 'listlabtestedcylinders', 'fa-thumbs-o-up'),
(16, 'hdip', 'Registered Users', 'view-records', 'fa-users'),
(17, 'admin', 'Stickers Management', 'transferStickers', 'fa-barcode'),
(18, 'apcng', 'Labs', 'showlabs', 'fa-sitemap'),
(19, 'apcng', 'Tested Cylinders', 'listlabtestedcylinders 	', 'fa-bolt'),
(20, 'apcng', 'Registered Users', 'view-records', 'fa-users'),
(23, 'hdip', 'Inspected Vehicles', 'Workshops', 'fa-car');
