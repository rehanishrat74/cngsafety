
-- --------------------------------------------------------

--
-- Table structure for table `logparticulars`
--

CREATE TABLE `logparticulars` (
  `logid` int(11) NOT NULL,
  `code` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vehicleCategory` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `businesstype` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stationno` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `make_n_type` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `chasis_no` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `engine_no` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `vehicle_name` varchar(191) COLLATE utf8mb4_bin DEFAULT NULL,
  `o_name` varchar(191) COLLATE utf8mb4_bin DEFAULT NULL,
  `o_cnic` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `registration_no` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `o_cell_no` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `o_address` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `isproduction` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `rectime` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `logparticulars`
--

INSERT INTO `logparticulars` (`logid`, `code`, `vehicleCategory`, `businesstype`, `stationno`, `user_id`, `make_n_type`, `chasis_no`, `engine_no`, `vehicle_name`, `o_name`, `o_cnic`, `registration_no`, `o_cell_no`, `o_address`, `isproduction`, `rectime`) VALUES
(4, 'PB6TJ8QMY', '3', 'Commercial', 'PID-17', '79', 'uu', '123', '563', 'fdr', 'trf', '32214-6853214-9', 'yy-321', '333-999-2583', 'dfg', '1', '2020-03-11'),
(5, 'O8MAPN6JH', '3', 'Commercial', 'PID-17', '79', '13march20', '652', '123', 'test Suzuki', 'trst rehan', '62238-6438521-3', 'dfh-853', '0333-2835985', 'fgt', '1', '2020-03-13'),
(6, 'EYONEIEGX', '5', 'Commercial', 'PID-17', '79', '13march20b', '658', '125', 'test 13m20', 'test13m20', '62295-5234856-6', 'ff-666', '0333-5558542', 'fcv', '1', '2020-03-13'),
(7, '060AZ4U7N', '2', 'Commercial', 'PID-13', '52', 'TOYOTA HIACE', '0002343', '1619881', 'TOYOTA HIACE', 'Sohail', '37201145841152', 'KZ66 ZYT', '03455740425', 'PLOT', '1', '2020-03-17'),
(8, '060AZ4U7N', '2', 'Commercial', 'PID-13', '52', 'TOYOTA HIACE', '0002343', '1619881', 'TOYOTA HIACE', 'Sohail', '37201145841152', 'KZ66 ZYT', '03455740425', 'PLOT', '1', '2020-03-17'),
(9, '060AZ4U7N', '2', 'Commercial', 'PID-13', '52', 'TOYOTA HIACE', '0002343', '1619881', 'TOYOTA HIACE', 'Sohail', '37201145841152', 'KZ66 ZYT', '03455740425', 'PLOT', '1', '2020-03-17'),
(10, '060AZ4U7N', '3', 'Commercial', 'PID-13', '52', 'TOYOTA HIACE', '0002343', '1619881', 'TOYOTA HIACE', 'Sohail', '37201145841152', 'KZ66 ZYT', '03455740425', 'PLOT', '1', '2020-03-17'),
(11, '060AZ4U7N', '5', 'Commercial', 'PID-13', '52', 'TOYOTA HIACE', '0002343', '1619881', 'TOYOTA HIACE', 'Sohail', '37201145841152', 'KZ66 ZYT', '03455740425', 'PLOT', '1', '2020-03-17'),
(12, '3KJ1TYTYH', '3', 'Commercial', 'PID-17', '79', 'suzuki170320', '123', '456', 'test suzuki', 'test 170320', '45502-6985215-6', 'rr-652', '02225556845', 'ed87', '1', '2020-03-17'),
(13, 'IXQ8EG4H0', '1', 'Private', 'PID-17', '79', '170320b', '123', '456', 'toyota', 'trehan', '78806-9852147-6', 'tt-654', '03336665785', 'tre', '1', '2020-03-17'),
(14, 'XQLTYNOG0', '1', 'Private', 'PID-17', '79', 'tr17march', '123', '456', 'suzu', 'yy', '43201-6985214-3', 'tt-66', '09995553245', 'dd', '1', '2020-03-17'),
(15, 'I0ONQIFHE', '4', 'Private', 'PID-17', '79', 'tmk', '658', '123', 'tr', 'tt', '42212-6523145-3', 'y-653', '03335554625', 'ddd', '1', '2020-03-17'),
(16, 'XQLTYNOG0', '3', 'Private', 'PID-17', '79', 'hi', '123', '456', 'ff', 't', '43301-6794120-3', 'R-666', '06662228545', 'dd', '1', '2020-03-18'),
(17, 'XQLTYNOG0', '3', 'Private', 'PID-17', '79', 'hi', '123', '456', 'ff', 't', '43301-6794120-3', 'R-666', '06662228545', 'dd', '1', '2020-03-18'),
(18, 'XQLTYNOG0', '3', 'Private', 'PID-17', '79', 'hi', '123', '456', 'ff', 't', '43201-6985214-3', 'tt-66', '06662228545', 'dd', '1', '2020-03-18'),
(19, '060AZ4U7N', '4', 'Commercial', 'PID-13', '52', 'TOYOTA HIACE', '0002343', '1619881', 'TOYOTA HIACE', 'Sohail', '37201145841152', 'KZ66 ZYT', '03455740425', 'PLOT', '1', '2020-03-19'),
(20, '060AZ4U7N', '4', 'Commercial', 'PID-13', '52', 'TOYOTA HIACE', '0002343', '1619881', 'TOYOTA HIACE', 'Sohail', '37201145841152', 'KZ66 ZYT', '03455740425', 'PLOT', '1', '2020-03-19');
